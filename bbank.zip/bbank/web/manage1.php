<?php
	$b1=$_REQUEST["b1"];
	$id=$_REQUEST["id"];
	$b1($id);
	function delete($id)

	{
		include 'db.php';
		mysqli_query($con,"delete from donors where id='$id'");
		header('location:managedonor1.php');
	}
	function edit($id)
	{
		header("location:edit1.php?id=$id");
	}
?>