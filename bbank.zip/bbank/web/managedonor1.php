<table border="1" width="100%">
	<tr><th>id</th><th>fname</th><th>lname</th><th>blood_type</th><th>address</th><th>mobile</th></tr>
	<?php
		include 'db.php';
		include 'header.php';
		$result=mysqli_query($con,"select * from donors");
		while ($arr=mysqli_fetch_assoc($result)):
	?>	

	<form action="manage1.php">
		<tr>
			<td><?php echo $arr["id"];?></td>
			<td><?php echo $arr["fname"];?></td>
			<td><?php echo $arr["lname"];?></td>
			<td><?php echo $arr["blood_type"];?></td>
			<td><?php echo $arr["address"];?></td>
			<td><?php echo $arr["mobile"];?></td>
			<td>
				<input type="hidden" value="<?php echo $arr["id"];?>" name="id"></input>
				<input type="submit" value="delete" name="b1"></input>
				<input type="submit" value="edit" name="b1"></input>
			</td>
		</tr>
	</form>
	<?php
endwhile;
?>

</table>




