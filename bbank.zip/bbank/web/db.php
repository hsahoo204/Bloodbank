<?php
$con=mysqli_connect('localhost','root','','donor');
if(!$con)
{
	echo("failed connection");
}
?>