<div class="bnr-btm-w3layouts" id="appoint">
		<div class="bnr-lft-agileits">
			<h3 class="subheading-agileits-w3layouts">Our services</h3>
			<ul>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Blood Donation</li>
				<li>
					<span class="fa fa-user-md" aria-hidden="true"></span>Blood Collection</li>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Online Blood  Delivery</li>
				<li>
					<span class="fa fa-user-md" aria-hidden="true"></span>Request For Bloods</li>
				<li>
					<span class="fa fa-stethoscope" aria-hidden="true"></span>Donors Screening</li>
			</ul>
		</div>