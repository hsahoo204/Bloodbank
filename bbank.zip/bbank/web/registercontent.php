<?php
if(isset($_POST["reg"]))
{
	include "db.php";
	$userid=$_POST["userid"];
	$password=$_POST["password"];
	$first_name=$_POST["first_name"];
	$last_name=$_POST["last_name"];
	$email=$_POST["email"];
	$dob=$_POST["dob"];
	$gender=$_POST["gender"];
	$blood_type=$_POST["blood_type"];
	$address=$_POST["address"];
	$city=$_POST["city"];
	$mobile=$_POST["mobile"];
	
	$sql="insert into users values('".$userid."','".$password."','".$first_name."','".$last_name."','".$email."','".$dob."','".$gender."',
		'".$blood_type."','".$address."','".$city."','".$mobile."')";
	if(mysqli_query($con,$sql))
	{
		header("location:success.php");
	}
}
?>
<?php include "header.php";
?>

<div id="templatemo_content" class="bnr-rgt-w3-agile">
<h1 align="center">Register here!</h1>
<form method="post">
<table align="center">
<tr><td>userid</td><td><input type="text"name="userid"/></td></tr>
<tr><td>password</td><td><input type="text"name="password"/></td></tr>
<tr><td>first_name</td><td><input type="text"name="first_name"/></td></tr>
<tr><td>last_name</td><td><input type="text"name="last_name"/></td></tr>
<tr><td>email</td><td><input type="text"name="email"/></td></tr>
<tr><td>dob</td><td><input type="date"name="dob"/></td></tr>

<tr><td>Gender 
<td><input type="radio" name="gender" value="male">Male 
<input type="radio" name="gender" value="female">Female
<input type="radio" name="gender" value="other">Other</td>
</td></tr>

<tr><td>blood_type</td><td><input type="text"name="blood_type"/></td></tr>
<tr><td>address</td><td><input type="text"name="address"/></td></tr>
<tr><td>city</td><td><input type="text"name="city"/></td></tr>
<tr><td>mobile</td><td><input type="text"name="mobile"/></td></tr>


<tr><td><input type="submit" value="register" name="reg"/></td><td></td></tr> 
</table>
</form>
</div>
