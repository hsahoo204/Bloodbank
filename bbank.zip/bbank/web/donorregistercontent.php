<?php
if(isset($_POST["reg"]))
{
	include "db.php";
	$id=$_POST["id"];
	$password=$_POST["password"];
	$fname=$_POST["fname"];
	$lname=$_POST["lname"];
	$sex=$_POST["sex"];
    $blood_type=$_POST["blood_type"];
	$diseases=$_POST["diseases"];
	$bday=$_POST["bday"];
	$address=$_POST["address"];
	$city=$_POST["city"];
	$donation_date=$_POST["donation_date"];
	$temp=$_POST["temp"];
	$bp=$_POST["bp"];
    $weight=$_POST["weight"];
	$mobile=$_POST["mobile"];
	
	$sql="insert into donors values('".$id."','".$password."','".$fname."','".$lname."','".$sex."','".$blood_type."','".$diseases."',
		'".$bday."','".$address."','".$city."','".$donation_date."','".$temp."','".$bp."','".$weight."','".$mobile."')";
	if(mysqli_query($con,$sql))
	{
		header("location:success.php");
	}
}
?>
<?php include "header.php";
?>

<div id="templatemo_content">
<h1 align="center">Register here!</h1>
<form method="post">
<table align="center">
<tr><td>id</td><td><input type="text"name="id" placeholder="enter your id"/></td></tr>
<tr><td>password</td><td><input type="password"name="password"placeholder="enter your password"/></td></tr>
<tr><td>fname</td><td><input type="text"name="fname"placeholder="enter your first name"/></td></tr>
<tr><td>lname</td><td><input type="text"name="lname"placeholder="enter your last name"/></td></tr>
<tr><td>sex 
<td><input type="radio" name="sex" value="male">Male 
<input type="radio" name="sex" value="female">Female
<input type="radio" name="sex" value="other">Other </td>
 </td></tr>
<tr><td>blood_type</td><td><input type="text"name="blood_type"placeholder="enter your blood type"/></td></tr>
<tr><td>diseases</td><td><input type="text"name="diseases"/></td></tr>

<tr><td>bday</td><td><input type="date"name="bday"placeholder="enter your birthday date"/></td></tr>

<tr><td>address</td><td><input type="text"name="address"/></td></tr>
<tr><td>city</td><td><input type="text"name="city"/></td></tr>
<tr><td>donation_date</td><td><input type="text"name="donation_date"/></td></tr>
<tr><td>temp</td><td><input type="text"name="temp"placeholder="enter your temperature"/></td></tr>
<tr><td>bp</td><td><input type="text"name="bp"placeholder="enter your blood pressure"/></td></tr>
<tr><td>weight</td><td><input type="text"name="weight"/></td></tr>
<tr><td>mobile</td><td><input type="text"name="mobile"/></td></tr>


<tr><td></td><td><input type="submit"  value="register"  name="reg"/></td><td></td></tr> 
</table>
</form>
</div>
<?php include "footer.php";
?>

