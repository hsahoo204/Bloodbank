<?php

if(isset($_POST['changebtn']))
{
	$curpwd=$_POST['curpwd'];
	$npwd=$_POST['npwd'];
	$uid=$_SESSION['userid'];
	include"db.php";
	$sql="update donors set password='".$npwd."'where userid='".$uid."'and password='".$curpwd."'";
	$q=mysqli_query($con,$sql);
	if($q)
	{
		$msg="Password Changed Successfully!!!";
	}

else{
	$msg="Error!!!";
}
}
?>

<form method="post"id="cngpwd">
<table align="center">
<tr>
<td>Current password</td>
<td><input type="password"name="curpwd"/></td>
</tr>
<tr>
<td>New Password</td>
<td><input type="password"name="npwd"id="pwd"/></td>
</tr>
<tr>
<td>Confirm Password</td>
<td><input type="password"name="cpwd"/></td>
</tr>
<tr>
<td colspan="2"align="center">
<input type="submit"value="Submit"name="changebtn">
<input type="reset"value="Reset">
</td>
</tr>
<tr><td colspan="2"><?php
if(isset($msg))
	{echo$msg;
		}
		?>
		</td>
		</tr>
</table>
</form>
