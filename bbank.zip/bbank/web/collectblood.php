<?php
if(isset($_POST["register"]))
{
	
	include "db.php";
	$serialno=$_POST["serialno"];
	$bloodgroup=$_POST["bloodgroup"];
	$totalnoofblood=$_POST["totalnoofblood"];
		
	$sql="insert into bloodstore values('".$serialno."','".$bloodgroup."','".$totalnoofblood."')";
	if(mysqli_query($con,$sql))
	{
		//echo $sql;
		header("location:success.php");
	}
}
?>



<center>
<h1>BLOOD DETAILS</h1>
<form method="post">
	<table>
		<tr>
			<td>
				serialno`
			</td>
			<td>
				<input type="text" name="serialno"/>
			</td>
		</tr>
		<tr>
			<td>
				bloodgroup
			</td>
			<td>
				<input type="text" name="bloodgroup"/>
			</td>
		</tr>
		<tr>
			<td>
				totalnoofblood
			</td>
			<td>
				<input type="text" name="totalnoofblood"/>
			</td>
		</tr>
		
		<tr><td></td><td><input type="submit" value="register" name="register"/></td></tr>
	</table>
</form>
</center>
