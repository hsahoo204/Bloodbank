<?php
if(isset($_POST['forgot']))
{
	$username=$_POST['username'];
	$dob=$_POST['dob'];
	$sql="select * from users where username='".$username."' and dob='".$dob."'";
	include 'db.php';
	$i=mysqli_query($con,$sql);
if($arr=mysqli_fetch_array($i))
{
	$pwd=$arr['password'];
	echo $pwd;
}
}
?>
<h1>Forgot password</h1>
<form method="post">
<table>
<tr><td>username</td><td><input type="text" name="username"/></td></tr>
<tr><td>dob</td><td><select name="dob"></td></tr>

<tr><td></td><td><input type="submit" value="get password" name="forgot"/></td></tr>
</table>
</form>
