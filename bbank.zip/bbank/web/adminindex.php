<?php
include "admintop.php";
include "banner.php";
include "content.php";
include "footer.php";
?>