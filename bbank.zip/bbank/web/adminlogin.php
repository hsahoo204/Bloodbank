		
<?php
session_start();
if(isset($_POST['login']))
{
	$adminid=$_POST['adminid'];
	$password=$_POST['password'];
	$sql="select * from admin where adminid='".$adminid."' and password='".$password."'";
	include 'db.php';
	$i=mysqli_query($con,$sql);
	if($arr=mysqli_fetch_array($i))
	{
		if($arr['status']==0)
		{
			$_SESSION['adminid']=$adminid;
			header('location:adminloginsuccess.php');
		}
		else
		{
			$msg="Account is Invalid";
		}
	}
	else
	{
	      $msg="Invalid adminid or password";	
	}
}
?>




<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login Form</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="loginbox">
<img src="images/users.jpg" class="user">
<h2>Login Here</h2>
<form method="post">
<P>adminid</P>
<input type="text" name="adminid" placeholder="Enter adminid"></input>
<p>Password</p>
<input type="password" name="password"placeholder="Enter Password"></input>
<input type="submit" name="login" value="Sign In"></input>
<center>DONT HAVE ANY ACCOUNt?</center>
<br/><center><a href="register.php">SIGN UP</a></center>
</form>
</div>
</body>
</html>




