<?php
session_start();
include "db.php";
$q=mysqli_query($con,"select * from employees where empid='".$_SESSION['empid']."'");
if($arr=mysqli_fetch_array($q))
{
	$empid=$arr['empid'];
	$username=$arr['username'];
	$mobile_nr=$arr['mobile_nr'];
	
}
?>
<?php include "header.php";
?>
<center>
<h1>Profile details</h1>
<form method="post">
<table>
<tr><td>username</td><td><input type="text" value="<?php echo $username;?>"name="username"/></td></tr>
<tr><td>empid</td><td><input type="text" value="<?php echo $empid;?>"name="empid"/></td></tr>
<tr><td>mobile_nr</td><td><input type="text" value="<?php echo $mobile_nr;?>"name="mobile_nr"/></td></tr>


<tr><td></td><td><input type="submit" value="update" name="upbtn"/></td></tr>
<tr><td></td><td></td></tr>
</table>
</form>
</center>
<?php include "footer.php";
?>
<?php
if(isset($_POST['upbtn']))
{
	include "db.php";
	$username1=$_POST['username'];
	$mobile_nr=$_POST['mobile_nr'];
	mysqli_query($con,"update employees set username='".$username."',mobile_nr='".$mobile_nr."' where empid='".$_SESSION['empid']."'");
}
?>
