		
<?php
session_start();
if(isset($_POST['login']))
{
	$email=$_POST['email'];
	$password=$_POST['password'];
	$sql="select * from users where email='".$email."' and password='".$password."'";
	include 'db.php';
	$i=mysqli_query($con,$sql);
	if($arr=mysqli_fetch_array($i))
	{
		if($arr['status']==0)
		{
			$_SESSION['email']=$email;
			header('location:success.php');
		}
		else
		{
			$msg="Account is Invalid";
		}
	}
	else
	{
	      $msg="Invalid email or password";	
	}
}
?>



<?php include "header.php";
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login Form</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="loginbox">
<img src="images/users.jpg" class="user">
<h2>Login Here</h2>
<form method="post">
<P>Email</P>
<input type="text" name="email" placeholder="Enter email"></input>
<p>Password</p>
<input type="password" name="password"placeholder="Enter Password"></input>
<input type="submit" name="login" value="Sign In"></input>
<center>DONT HAVE ANY ACCOUNt?</center>
<br/><center><a href="register.php">SIGN UP</a></center>
</form>
</div>
</body>
</html>




