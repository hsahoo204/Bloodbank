<?php
$donarid=$_REQUEST['id'];
include 'db.php';
if(isset($_REQUEST["b1"]))
{
	$fname=$_REQUEST['fname'];
	$lname=$_REQUEST['lname'];
	$blood_type=$_REQUEST['blood_type'];
	$address=$_REQUEST['address'];
	$mobile=$_REQUEST['mobile'];
	//fname='$fname',lname='$lname',blood_type='$blood_type',
		//address='$address' mobile='$mobile' 
	$s=mysqli_query($con,"update donors set fname='$fname', lname='$lname', blood_type='$blood_type', 
		address='$address', mobile='$mobile' where id='$donarid'");
	if(isset($s))
	{
		//echo $s;
		header('location:managedonor.php');
	}
	//echo $s;
	//

}
$result=mysqli_query($con,"select * from donors where id='$donarid'");
$arr=mysqli_fetch_assoc($result);
?>
<form>
<table border="1px">
<tr>
     <th> ID </th>
     <th>  FIRSTNAME  </th> 
       <th> LNAME </th>  
                   
       <th> BLOODTYPE </th>
       <th>ADDRESS</th>
       <th>MOBILE </th>
       <th>Action</th>
      </tr>
                               
 
  <tr>
  <td>
  <?php echo $arr["id"];?>
  </td>
  <td>
  <input value="<?php echo $arr["fname"];?>" name="fname">
  </td>
  <td>
  <input value="<?php echo $arr["lname"];?>" name="lname">
  </td>
  <td>
  <input value="<?php echo $arr["blood_type"];?>" name="blood_type">
  </td>
  <td>
  <input value="<?php echo $arr["address"];?>" name="address">
  </td>
  <td>
 <input value="<?php echo $arr["mobile"];?>" name="mobile">
  </td>
  <td>
 <input type="hidden" value="<?php echo $arr["id"];?>"name="id"/>
<input type="submit" value="update" name="b1"/>
 </td>
</tr>
</table>
</form>