<table border="1" width="100%">
	<tr><th> serialno</th> <th> bloodgroup</th> <th>totalnoofblood</th></tr>
	<?php
		include 'db.php';
		include 'header.php';
		$result=mysqli_query($con,"select * from bloodstore");
		while ($arr=mysqli_fetch_assoc($result)):
	?>	
	<form action="manage.php">
		<tr>
			<td><?php echo $arr["serialno"];?></td>
			<td><?php echo $arr["bloodgroup"];?></td>
			<td><?php echo $arr["totalnoofblood"];?></td>
			
		</tr>
	</form>
	<?php
endwhile;
?>

</table>
<?php include 'footer.php'?>