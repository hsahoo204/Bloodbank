<?php
if(isset($_POST["reg"]))
{
	include "db.php";

	
	$patientname=$_POST["patientname"];
	$hospitalname=$_POST["hospitalname"];
	$bloodgroup=$_POST["bloodgroup"];
	$date=$_POST["date"];
	$address=$_POST["address"];

		
	$sql="insert into requestblood values('".$patientname."','".$hospitalname."','".$bloodgroup."','".$date."','".$address."')";
	if(mysqli_query($con,$sql))
	{
		header("location:success.php");
	}
}
?>
<?php include 'header.php'; ?>

<div id="templatemo_content">
<h1 align="center">Register here!</h1>
<form method="post">
<table align="center">
<tr><td>patientname</td><td><input type="text"name="patientname" placeholder="enter your patientname"/></td></tr>
<tr><td>hospitalname</td><td><input type="text"name="hospitalname"placeholder="enter your hospitalname"/></td></tr>
<tr><td>bloodgroup</td><td><input type="text"name="bloodgroup"placeholder="enter your bloodgroup name"/></td></tr>


<tr><td>date</td><td><input type="text"name="date"placeholder="enter date"/></td></tr>


<tr><td>address</td><td><input type="text"name="address"/></td></tr>


<tr><td><input type="submit" value="register" name="reg"/></td><td></td></tr> 
</table>
</form>
</div>

<?php include 'footer.php'; ?>