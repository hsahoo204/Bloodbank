
<div id="templatemo_content">
<h1>Login here</h1>
<form method="post">
<table>
<tr><td>email</td><td><input type="text" name="email"/></td></tr>
<tr><td>password</td><td><input type="text" name="password"/></td></tr>
<tr><td><input type="submit" value="login" name="login"/></td><td><a href="forgotpassword.php">forgot password</a></td></tr>
<tr><td><?php if(isset($msg)) echo $msg;?></td></tr>
</table>
</form>
</div>
