<?php
	$b1=$_REQUEST["b1"];
	$serialno=$_REQUEST["serialno"];
	$b1($serialno);
	function delete($serialno)

	{
		include 'db.php';
		mysqli_query($con,"delete from bloodstore where serialno='$serialno'");
		header('location:managebloodlist.php');
	}
	function edit($serialno)
	{
		header("location:edit.php?serialno=$serialno");
	}
?>